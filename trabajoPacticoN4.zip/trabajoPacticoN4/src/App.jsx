import './App.css'
import TraerPersonas from "./components/TraerPersonas";

function App() {


  return (
    <div>
      <h1>Listado de Personas</h1>
      <TraerPersonas />
    </div>
  );

}

export default App
