// Simulamos una base de datos con un array
const personas = [
  { id: 1, nombre: "Juan", apellido: "Pérez", edad: 2, email: "juan@gmail.com" },
  { id: 2, nombre: "Ana", apellido: "Gómez", edad: 25, email: "ana@gmail.com" },
  { id: 3, nombre: "Luis", apellido: "Martínez", edad: 35, email: "luis@gmail.com" },
  { id: 4, nombre: "Carla", apellido: "Rodríguez", edad: 28, email: "carla@gmail.com" },
  { id: 5, nombre: "Pedro", apellido: "Fernández", edad: 40, email: "pedro@gmail.com" }
];

module.exports = personas;